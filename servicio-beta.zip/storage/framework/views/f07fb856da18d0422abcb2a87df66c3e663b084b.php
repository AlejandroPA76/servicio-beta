<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <div class="card">
                <div class="card-header">
                    <a class="btn btn-primary" href="<?php echo e(route('agregar.producto')); ?>">Agregar Producto</a>
                    <a class="btn btn-primary" href="<?php echo e(route('inicio')); ?>">Solicitar</a>
                </div>

                <div class="card-body">
                   
                    <?php if(session('info')): ?>
                   <div class="alert alert-success">
                        <?php echo e(session('info')); ?>

                   </div>
                    <?php endif; ?>
                    <table class="table">
                          <thead>
                            <tr>
            
                              <th >Codigo</th>
                              <th >Responsable</th>
                              <th >Producto</th>
                              <th >Descripcion</th>
                              <th >Stock</th>
                              <th >Medida</th>
                              <th >Accion</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td>
                                    <?php echo e($producto->codigo); ?>

                                </td>

                                  <td>
                                    <?php echo e($producto->responsable); ?>

                                  </td>

                                 <td>
                                    <?php echo e($producto->nombre); ?>

                                </td>
                                 <td>
                                    <?php echo e($producto->descripcion); ?>

                                </td>
                        
                                <td>
                                    <?php echo e($producto->stock); ?>

                                </td>
                                <td>
                                    <?php echo e($producto->medida); ?>

                                </td>
                                <td>
        <a href="<?php echo e(route('editar.producto', $producto->id)); ?>" class="btn btn-info btn-sm">Editar</a>

         <a href="javascript: document.getElementById('delete-<?php echo e($producto->id); ?>').submit()" class="btn btn-danger btn-sm" onclick="return confirm('deseas borrar?')">Eliminar</a>
            <form id=delete-<?php echo e($producto->id); ?> action="<?php echo e(route('eliminar.producto', $producto->id)); ?>" method="POST">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </td>
                                 
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alex/misProyectos/servicio-beta/resources/views/home.blade.php ENDPATH**/ ?>